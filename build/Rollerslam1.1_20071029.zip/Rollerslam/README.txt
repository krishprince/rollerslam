                             ROLLERSLAM README

 *  Rollerslam - The Global Fusion Sport of the Third Millennium
 *  Copyright (C) 2007  ORCAS Research Group
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 *  http://rollerslam.googlecode.com
 
 This version: Rollerslam 1.1 revision 619
 
 Before you execute Rollerslam you will Java Runtime Environment (JRE) 6  
 or greater (http://java.sun.com/javase/downloads/?intcmp=1281),
 and EcLiPsE 5.10 (http://eclipse.crosscoreop.com/) 
 with FluxAgent (http://www.fluxagent.org/system.htm) installed on your system.
 
 LogPlayer requires a screen with more than 768 pixels of height.
 
 Note: One clean copy of ECLiPSe for Windows will be available in 
 Rollerslam website (http://rollerslam.googlecode.com).
 
 Simple execution:
 
 1. Configure settings.properties with your local settings.
 2. Execute runAllInOne.bat
 3. Wait the window to show up
 4. Execute runReferee.bat
 
 For replay a game:
 
 1. Configure settings.properties with your local settings.
 2. Execute runLogPlayer.bat
 
 
 IMPORTANT: Always check http://rollerslam.googlecode.com for news.